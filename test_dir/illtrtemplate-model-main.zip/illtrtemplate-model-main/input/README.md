Input data directories should be placed in this directory.
The preunwarped data from the data will be downloaded automatically to this directory.
